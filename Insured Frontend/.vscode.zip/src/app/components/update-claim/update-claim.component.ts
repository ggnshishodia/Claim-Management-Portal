import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { DataService } from '../../data.service';
 

@Component({
  selector: 'app-update-claim',
  templateUrl: './update-claim.component.html',
  styleUrls: ['./update-claim.component.css'],
  providers: [DataService]
})
export class UpdateClaimComponent implements OnInit {
  claimId!: number;

 

  constructor(private route: ActivatedRoute, private http: HttpClient) { }

 

  ngOnInit(): void {
  const claimIdParam = this.route.snapshot.paramMap.get('claimId');
  if (claimIdParam) {
    this.claimId = +claimIdParam;
  } else {
    // Handle the case when claimId is null
    // For example, navigate to an error page or display an error message
  }
}

 

  acceptClaim(): void {
    this.updateClaim({ claimId: this.claimId, accept: true });
  }

 

  withdrawClaim(): void {
    this.updateClaim({ claimId: this.claimId, accept: false, withdraw: true });
  }

 

  closeClaim(): void {
    this.updateClaim({ claimId: this.claimId, accept: false });
  }

 

  private updateClaim(data: any): void {
    this.http.put(`/api/claims/${data.claimId}`, data).subscribe(
      response => {
        // Handle success response
        console.log('Claim updated successfully');
      },
      error => {
        // Handle error response
        console.error('Failed to update claim');
      }
    );
  }
}